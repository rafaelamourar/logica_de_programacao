/* ============================================================
   PORTFÓLIO — RAFAELA MOURA
   Arquivo: script.js
   Descrição: Interatividade, animações e funcionalidades do portfólio
   ============================================================ */

/* ============================================================
   1. UTILITÁRIOS
   ============================================================ */

/**
 * Seleciona um único elemento do DOM.
 * @param {string} selector - Seletor CSS
 * @returns {Element|null}
 */
const $ = (selector) => document.querySelector(selector);

/**
 * Seleciona múltiplos elementos do DOM.
 * @param {string} selector - Seletor CSS
 * @returns {NodeList}
 */
const $$ = (selector) => document.querySelectorAll(selector);

/* ============================================================
   2. NAVBAR — SCROLL E MENU MOBILE
   ============================================================ */

const navbar    = $('#navbar');
const hamburger = $('#hamburger');
const navLinks  = $('#navLinks');
const allNavLinks = $$('.nav-link');

/**
 * Adiciona/remove a classe "scrolled" na navbar conforme o scroll.
 * Isso ativa o fundo glassmorphism ao rolar a página.
 */
function handleNavbarScroll() {
  if (window.scrollY > 60) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
}

/**
 * Alterna o menu mobile (hamburguer).
 */
function toggleMobileMenu() {
  hamburger.classList.toggle('open');
  navLinks.classList.toggle('open');
  // Bloqueia o scroll do body quando o menu está aberto
  document.body.style.overflow = navLinks.classList.contains('open') ? 'hidden' : '';
}

/**
 * Fecha o menu mobile ao clicar em um link.
 */
function closeMobileMenu() {
  hamburger.classList.remove('open');
  navLinks.classList.remove('open');
  document.body.style.overflow = '';
}

// Fecha o menu ao clicar fora dele
document.addEventListener('click', (e) => {
  if (
    navLinks.classList.contains('open') &&
    !navLinks.contains(e.target) &&
    !hamburger.contains(e.target)
  ) {
    closeMobileMenu();
  }
});

// Eventos da navbar
window.addEventListener('scroll', handleNavbarScroll, { passive: true });
hamburger.addEventListener('click', toggleMobileMenu);
allNavLinks.forEach((link) => link.addEventListener('click', closeMobileMenu));

// Executa na carga para caso a página já esteja rolada
handleNavbarScroll();

/* ============================================================
   3. LINK ATIVO NA NAVBAR — INTERSECTION OBSERVER
   ============================================================ */

/**
 * Observa as seções e marca o link correspondente como ativo
 * conforme o usuário rola a página.
 */
function initActiveNavLink() {
  const sections = $$('section[id]');

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          // Remove "active" de todos os links
          allNavLinks.forEach((link) => link.classList.remove('active'));
          // Adiciona "active" no link correspondente à seção visível
          const activeLink = $(`.nav-link[href="#${entry.target.id}"]`);
          if (activeLink) activeLink.classList.add('active');
        }
      });
    },
    {
      rootMargin: '-40% 0px -55% 0px', // Ativa quando a seção está no centro da tela
    }
  );

  sections.forEach((section) => observer.observe(section));
}

initActiveNavLink();

/* ============================================================
   4. ANIMAÇÕES DE REVEAL AO ROLAR (Intersection Observer)
   ============================================================ */

/**
 * Observa elementos com a classe "reveal" e adiciona "visible"
 * quando entram no viewport, disparando a animação CSS.
 */
function initRevealAnimations() {
  const revealElements = $$('.reveal');

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry, index) => {
        if (entry.isIntersecting) {
          // Adiciona um pequeno delay escalonado para elementos em sequência
          setTimeout(() => {
            entry.target.classList.add('visible');
          }, index * 80);
          // Para de observar após revelar (animação ocorre apenas uma vez)
          observer.unobserve(entry.target);
        }
      });
    },
    {
      threshold: 0.12, // Inicia quando 12% do elemento está visível
      rootMargin: '0px 0px -40px 0px',
    }
  );

  revealElements.forEach((el) => observer.observe(el));
}

initRevealAnimations();

/* ============================================================
   5. SCROLL SUAVE PARA ÂNCORAS
   ============================================================ */

/**
 * Implementa scroll suave com offset para compensar a navbar fixa.
 * Funciona em navegadores que não suportam scroll-behavior nativo.
 */
function initSmoothScroll() {
  const NAVBAR_HEIGHT = 80; // Altura aproximada da navbar em pixels

  $$('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', (e) => {
      const targetId = anchor.getAttribute('href');
      if (targetId === '#') return;

      const target = $(targetId);
      if (!target) return;

      e.preventDefault();

      const targetTop = target.getBoundingClientRect().top + window.scrollY - NAVBAR_HEIGHT;

      window.scrollTo({
        top: targetTop,
        behavior: 'smooth',
      });
    });
  });
}

initSmoothScroll();

/* ============================================================
   6. ANO DINÂMICO NO RODAPÉ
   ============================================================ */

/**
 * Atualiza automaticamente o ano no rodapé.
 */
const yearEl = $('#year');
if (yearEl) {
  yearEl.textContent = new Date().getFullYear();
}

/* ============================================================
   7. FORMULÁRIO DE CONTATO — VALIDAÇÃO E FEEDBACK
   ============================================================ */

const contactForm   = $('#contactForm');
const formFeedback  = $('#formFeedback');

/**
 * Valida o formulário de contato e exibe feedback ao usuário.
 * Como não há backend, simula o envio com um timeout.
 */
function handleFormSubmit(e) {
  e.preventDefault();

  const nome     = $('#nome').value.trim();
  const email    = $('#email').value.trim();
  const mensagem = $('#mensagem').value.trim();

  // Validação básica
  if (!nome || !email || !mensagem) {
    showFeedback('Por favor, preencha todos os campos.', 'error');
    return;
  }

  if (!isValidEmail(email)) {
    showFeedback('Por favor, insira um e-mail válido.', 'error');
    return;
  }

  // Simula envio (substitua por fetch/API real se necessário)
  const submitBtn = contactForm.querySelector('button[type="submit"]');
  submitBtn.disabled = true;
  submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';

  setTimeout(() => {
    showFeedback(
      `Obrigada pelo contato, ${nome}! Responderei em breve. 💜`,
      'success'
    );
    contactForm.reset();
    submitBtn.disabled = false;
    submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Enviar Mensagem';
  }, 1800);
}

/**
 * Exibe uma mensagem de feedback no formulário.
 * @param {string} message - Texto da mensagem
 * @param {'success'|'error'} type - Tipo do feedback
 */
function showFeedback(message, type) {
  formFeedback.textContent = message;
  formFeedback.className = `form-feedback ${type}`;

  // Remove o feedback após 5 segundos
  setTimeout(() => {
    formFeedback.className = 'form-feedback';
    formFeedback.textContent = '';
  }, 5000);
}

/**
 * Valida formato de e-mail com regex simples.
 * @param {string} email
 * @returns {boolean}
 */
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

if (contactForm) {
  contactForm.addEventListener('submit', handleFormSubmit);
}

/* ============================================================
   8. EFEITO DE DIGITAÇÃO NO HERO (Typewriter)
   ============================================================ */

/**
 * Cria um efeito de digitação no elemento alvo, ciclando
 * entre uma lista de textos.
 */
function initTypewriter() {
  const taglineEl = $('.hero-tagline');
  if (!taglineEl) return;

  const phrases = [
    'Estudante de TI · Desenvolvedora Web · Apaixonada por Tecnologia',
    'Explorando Redes · Criando Interfaces · Aprendendo Sempre',
    'HTML · CSS · JavaScript · Cisco · Canva · IA',
  ];

  let phraseIndex = 0;
  let charIndex   = 0;
  let isDeleting  = false;
  let isPaused    = false;

  const TYPING_SPEED   = 55;   // ms por caractere ao digitar
  const DELETING_SPEED = 28;   // ms por caractere ao apagar
  const PAUSE_AFTER    = 2400; // ms de pausa após digitar a frase completa
  const PAUSE_BEFORE   = 400;  // ms de pausa antes de começar a digitar

  function type() {
    if (isPaused) return;

    const currentPhrase = phrases[phraseIndex];

    if (!isDeleting) {
      // Digitando
      taglineEl.textContent = currentPhrase.slice(0, charIndex + 1);
      charIndex++;

      if (charIndex === currentPhrase.length) {
        // Pausa ao terminar de digitar
        isPaused = true;
        setTimeout(() => {
          isPaused  = false;
          isDeleting = true;
          requestAnimationFrame(tick);
        }, PAUSE_AFTER);
        return;
      }
    } else {
      // Apagando
      taglineEl.textContent = currentPhrase.slice(0, charIndex - 1);
      charIndex--;

      if (charIndex === 0) {
        // Passa para a próxima frase
        isDeleting  = false;
        phraseIndex = (phraseIndex + 1) % phrases.length;
        isPaused    = true;
        setTimeout(() => {
          isPaused = false;
          requestAnimationFrame(tick);
        }, PAUSE_BEFORE);
        return;
      }
    }

    setTimeout(() => requestAnimationFrame(tick), isDeleting ? DELETING_SPEED : TYPING_SPEED);
  }

  function tick() {
    type();
  }

  // Inicia após as animações do hero terminarem
  setTimeout(() => requestAnimationFrame(tick), 1200);
}

initTypewriter();

/* ============================================================
   9. EFEITO PARALLAX SUAVE NOS BLOBS DO HERO
   ============================================================ */

/**
 * Move os blobs decorativos levemente conforme o mouse se move,
 * criando um efeito de profundidade sutil.
 */
function initParallaxBlobs() {
  const blobs = $$('.blob');
  if (!blobs.length) return;

  // Desativa em dispositivos touch para melhor performance
  if (window.matchMedia('(pointer: coarse)').matches) return;

  document.addEventListener('mousemove', (e) => {
    const { clientX, clientY } = e;
    const cx = window.innerWidth  / 2;
    const cy = window.innerHeight / 2;

    const dx = (clientX - cx) / cx; // -1 a 1
    const dy = (clientY - cy) / cy; // -1 a 1

    blobs.forEach((blob, i) => {
      const factor = (i + 1) * 12; // Intensidade diferente por blob
      blob.style.transform = `translate(${dx * factor}px, ${dy * factor}px)`;
    });
  });
}

initParallaxBlobs();

/* ============================================================
   10. SKILL CARDS — EFEITO DE ENTRADA ESCALONADO
   ============================================================ */

/**
 * Adiciona delays escalonados nos cards de habilidades
 * para uma entrada em cascata mais elegante.
 */
function initSkillCardDelays() {
  const skillGroups = $$('.skills-group');

  skillGroups.forEach((group) => {
    const cards = group.querySelectorAll('.skill-card');
    cards.forEach((card, index) => {
      card.style.transitionDelay = `${index * 60}ms`;
    });
  });
}

initSkillCardDelays();

/* ============================================================
   11. INICIALIZAÇÃO GERAL
   ============================================================ */

/**
 * Ponto de entrada principal — executa após o DOM estar pronto.
 */
document.addEventListener('DOMContentLoaded', () => {
  console.log('🚀 Portfólio da Rafaela Moura carregado com sucesso!');

  // Re-inicializa os reveals para elementos já visíveis no carregamento
  setTimeout(() => {
    $$('.reveal').forEach((el) => {
      const rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight * 0.9) {
        el.classList.add('visible');
      }
    });
  }, 300);
});